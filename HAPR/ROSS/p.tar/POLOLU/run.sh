make clean
make all
make install
sync
